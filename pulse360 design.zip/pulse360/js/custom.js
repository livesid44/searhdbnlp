$(document).ready(function() {
	$(".sideNav .dropdown>a span").append('<i class="bi bi-chevron-down"></i>');

	$(".sideNav").append('<a href="javascript: void(0);" class="toggleMenuLink two"></a>');

	$("body").append('<div class="navOverlay"></div>');

	$(".toggleMenuLink").click(function() {
		
		$(".navOverlay").toggleClass('active');

		$(".toggleMenuLink").toggleClass("active");
		$('.sideNav').toggleClass("active");
		$('body').toggleClass("navOpen");

		$('.sideNav .dropdown>a').removeClass('active');
		$('.sideNav .subMenu').hide('slow');

	});
	$(".navOverlay").click(function() {
		$(this).removeClass("active");

		$(".toggleMenuLink").toggleClass("active");
		$('.sideNav').toggleClass("active");
		$('body').toggleClass("navOpen");

		$('.sideNav .dropdown>a').removeClass('active');
		$('.sideNav .subMenu').hide('slow');
	});


	$(".sideNav .dropdown>a").click(function() {
		$(this).toggleClass('active');
		$('.sideNav .dropdown>a').not(this).removeClass('active');

		$('.sideNav .dropdown>a').not(this).siblings('.sideNav .subMenu').hide('slow');
		$(this).siblings('.sideNav .subMenu').toggle('slow');
	});

	/*if ($(window).innerWidth() >= 768) {
		$('.toggleMenuLink').addClass("active");
		$('.sideNav').addClass("active");
		$('body').toggleClass("navOpen");

		$('.navFalse').removeClass("navOpen");
	};*/


});


$(document).ready(function() {
	$(function() {
		$(".datepicker").datetimepicker();
	});

	//$(".editBtn").attr({'data-bs-toggle':"tooltip", 'data-bs-title':"Edit"});
	//$(".deleteBtn").attr({'data-bs-toggle':"tooltip", 'data-bs-title':"Delete"});

	var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
	var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
	return new bootstrap.Tooltip(tooltipTriggerEl)
	
	});

	//$('.panel').find('.form-line.error').closest('.panel-collapse').addClass('in');

	
	$('.onOffSwitch input').change(function(){
        if($(this).is(":checked")) {
            $(this).closest('.onOffSwitch').addClass('switchOn');
        } else {
            $(this).closest('.onOffSwitch').removeClass('switchOn');
        }
    });


	$('.tableToGraph input').change(function(){
        if($(this).is(":checked")) {
            $(this).closest('.tab-pane').find('.tableSec').css('display', 'none');
            $(this).closest('.tab-pane').find('.graphSec').css('display', 'block');
			$(this).prop('checked', true);
        } else {
            $(this).closest('.tab-pane').find('.tableSec').css('display', 'block');
            $(this).closest('.tab-pane').find('.graphSec').css('display', 'none');
			$(this).prop('checked', false);
        }
    });


	$(".sortB .sortIcon").click(function() {
		$(this).addClass('current');
		$(this).siblings().removeClass('current');
	});


}); 

                             